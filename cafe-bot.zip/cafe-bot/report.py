"""Чистая логика расчёта дня (без Telegram) — легко тестировать."""
from dataclasses import dataclass, field


@dataclass
class DayReport:
    day: str
    lines: list = field(default_factory=list)   # (name, unit, prepared, left, sold, revenue)
    calc_revenue: float = 0.0
    missing_left: list = field(default_factory=list)
    cash: float = 0.0
    kaspi: float = 0.0
    fact_revenue: float = 0.0
    diff: float = 0.0           # факт - расчёт (минус = недостача)
    expenses_by_cat: dict = field(default_factory=dict)
    expenses_total: float = 0.0
    net: float = 0.0            # факт - все расходы
    drawer: float | None = None


def build(day, stock_rows, expenses, cash_row) -> DayReport:
    r = DayReport(day)
    for s in stock_rows:
        prepared = s["prepared"] or 0
        left = s["left"]
        if left is None:
            r.missing_left.append(s["name"])
            sold, rev = 0, 0
        else:
            sold = max(prepared - left, 0)
            rev = sold * s["price"]
        r.lines.append((s["name"], s["unit"], prepared, left, sold, rev))
        r.calc_revenue += rev
    if cash_row:
        r.cash, r.kaspi = cash_row["cash"] or 0, cash_row["kaspi"] or 0
        r.drawer = cash_row["drawer"]
    r.fact_revenue = r.cash + r.kaspi
    r.diff = r.fact_revenue - r.calc_revenue
    for e in expenses:
        r.expenses_by_cat[e["category"]] = r.expenses_by_cat.get(e["category"], 0) + e["amount"]
        r.expenses_total += e["amount"]
    r.net = r.fact_revenue - r.expenses_total
    return r


def money(x: float) -> str:
    return f"{x:,.0f}".replace(",", " ") + " ₸"


def num(x) -> str:
    return "—" if x is None else (str(int(x)) if float(x).is_integer() else f"{x:g}")


def format_text(r: DayReport) -> str:
    out = [f"📊 Итог за {r.day}", ""]
    for name, unit, prep, left, sold, rev in r.lines:
        out.append(f"• {name}: готово {num(prep)}, осталось {num(left)}, продано {num(sold)} = {money(rev)}")
    if r.missing_left:
        out.append(f"\n⚠️ Нет остатка: {', '.join(r.missing_left)}")
    out += ["", f"Расчётная выручка: {money(r.calc_revenue)}",
            f"Факт: нал {money(r.cash)} + Kaspi {money(r.kaspi)} = {money(r.fact_revenue)}"]
    if r.fact_revenue or r.calc_revenue:
        sign = "✅ сходится" if abs(r.diff) < 1 else ("➕ излишек" if r.diff > 0 else "➖ недостача")
        out.append(f"Разница: {money(r.diff)} ({sign})")
    if r.expenses_by_cat:
        out.append("\nРасходы:")
        out += [f"• {c}: {money(v)}" for c, v in r.expenses_by_cat.items()]
        out.append(f"Всего расходов: {money(r.expenses_total)}")
    out.append(f"\n💰 Чистыми за день: {money(r.net)}")
    if r.drawer is not None:
        out.append(f"В кассе оставлено: {money(r.drawer)}")
    return "\n".join(out)
