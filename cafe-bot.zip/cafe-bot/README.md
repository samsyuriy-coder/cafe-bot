# Бот учёта кафе (Telegram)

Заменяет тетрадь: приготовили → остатки → касса → расходы → итог дня с проверкой «расчёт vs факт».

## Как пользоваться
Сотрудники: «🍳 Приготовили», «📦 Остатки», «💸 Расход», «💰 Касса».
Владелец дополнительно: «📊 Итог дня», `/export` (Excel), `/menu`, `/add Название;цена;ед`, `/del Название`, `/undo`.

Продано = приготовлено − остаток. Выручка = продано × цена. Бот сравнивает её с наличными + Kaspi.

## Запуск
1. @BotFather → `/newbot` → скопировать токен.
2. `cp .env.example .env`, вписать `BOT_TOKEN`.
3. Запустить `python bot.py`, написать боту `/myid`, вписать ID в `OWNER_IDS` / `STAFF_IDS`, перезапустить.
4. `pip install -r requirements.txt`

## Публикация на GitHub
```
git init && git add . && git commit -m "Cafe bot"
git branch -M main
git remote add origin https://github.com/<логин>/cafe-bot.git
git push -u origin main
```
Файл `.env` в репозиторий не попадает (см. `.gitignore`) — токен хранить только там.

## Хостинг
Любой VPS или Railway/Render: команда запуска `python bot.py`, переменные из `.env`, диск для файла `cafe.db`.

## Тесты
`pytest tests`
