from openpyxl import Workbook
from openpyxl.styles import Font
from report import build


def export_xlsx(db, path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Дни"
    ws.append(["Дата", "Расчётная выручка", "Нал", "Kaspi", "Факт", "Разница", "Расходы", "Чистыми"])
    det = wb.create_sheet("Блюда")
    det.append(["Дата", "Блюдо", "Приготовлено", "Остаток", "Продано", "Выручка"])
    for day in db.days():
        r = build(day, db.stock_rows(day), db.expenses(day), db.cash_row(day))
        ws.append([day, r.calc_revenue, r.cash, r.kaspi, r.fact_revenue, r.diff, r.expenses_total, r.net])
        for n, _u, p, l, s, rev in r.lines:
            det.append([day, n, p, l, s, rev])
    for sh in (ws, det):
        for c in sh[1]:
            c.font = Font(bold=True)
    wb.save(path)
