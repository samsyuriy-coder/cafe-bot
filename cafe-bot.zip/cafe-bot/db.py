"""SQLite-хранилище. Все даты — строки ISO (YYYY-MM-DD)."""
import csv
import sqlite3
from pathlib import Path


class DB:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS items(
                id INTEGER PRIMARY KEY, name TEXT UNIQUE, price REAL, unit TEXT, active INTEGER DEFAULT 1);
            CREATE TABLE IF NOT EXISTS stock(          -- приготовлено / остаток по блюдам за день
                day TEXT, item_id INTEGER, prepared REAL DEFAULT 0, left REAL,
                PRIMARY KEY(day, item_id));
            CREATE TABLE IF NOT EXISTS expenses(
                id INTEGER PRIMARY KEY, day TEXT, category TEXT, amount REAL, note TEXT, user_id INTEGER);
            CREATE TABLE IF NOT EXISTS cash(           -- фактическая выручка за день
                day TEXT PRIMARY KEY, cash REAL DEFAULT 0, kaspi REAL DEFAULT 0, drawer REAL);
            """
        )

    # ---- меню
    def load_menu_csv(self, path: str):
        if not Path(path).exists() or self.conn.execute("SELECT 1 FROM items").fetchone():
            return
        with open(path, encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                self.upsert_item(r["название"].strip(), float(r["цена"]), r.get("ед", "шт"))

    def upsert_item(self, name, price, unit="шт"):
        self.conn.execute(
            "INSERT INTO items(name,price,unit) VALUES(?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET price=excluded.price, unit=excluded.unit, active=1",
            (name, price, unit))
        self.conn.commit()

    def deactivate_item(self, name) -> bool:
        cur = self.conn.execute("UPDATE items SET active=0 WHERE name=?", (name,))
        self.conn.commit()
        return cur.rowcount > 0

    def items(self):
        return self.conn.execute("SELECT * FROM items WHERE active=1 ORDER BY name").fetchall()

    def item(self, item_id):
        return self.conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()

    # ---- остатки
    def add_prepared(self, day, item_id, qty):
        self.conn.execute(
            "INSERT INTO stock(day,item_id,prepared) VALUES(?,?,?) "
            "ON CONFLICT(day,item_id) DO UPDATE SET prepared=prepared+excluded.prepared",
            (day, item_id, qty))
        self.conn.commit()

    def set_left(self, day, item_id, qty):
        self.conn.execute(
            "INSERT INTO stock(day,item_id,left) VALUES(?,?,?) "
            "ON CONFLICT(day,item_id) DO UPDATE SET left=excluded.left", (day, item_id, qty))
        self.conn.commit()

    def stock_rows(self, day):
        return self.conn.execute(
            "SELECT i.name,i.price,i.unit,s.prepared,s.left FROM stock s "
            "JOIN items i ON i.id=s.item_id WHERE s.day=? ORDER BY i.name", (day,)).fetchall()

    # ---- расходы / касса
    def add_expense(self, day, category, amount, note, user_id):
        self.conn.execute("INSERT INTO expenses(day,category,amount,note,user_id) VALUES(?,?,?,?,?)",
                          (day, category, amount, note, user_id))
        self.conn.commit()

    def expenses(self, day):
        return self.conn.execute("SELECT * FROM expenses WHERE day=? ORDER BY id", (day,)).fetchall()

    def undo_last_expense(self, day, user_id):
        row = self.conn.execute(
            "SELECT id,category,amount,note FROM expenses WHERE day=? AND user_id=? ORDER BY id DESC LIMIT 1",
            (day, user_id)).fetchone()
        if row:
            self.conn.execute("DELETE FROM expenses WHERE id=?", (row["id"],))
            self.conn.commit()
        return row

    def set_cash(self, day, cash=None, kaspi=None, drawer=None):
        self.conn.execute("INSERT OR IGNORE INTO cash(day) VALUES(?)", (day,))
        for col, val in (("cash", cash), ("kaspi", kaspi), ("drawer", drawer)):
            if val is not None:
                self.conn.execute(f"UPDATE cash SET {col}=? WHERE day=?", (val, day))
        self.conn.commit()

    def cash_row(self, day):
        return self.conn.execute("SELECT * FROM cash WHERE day=?", (day,)).fetchone()

    def days(self):
        return [r[0] for r in self.conn.execute(
            "SELECT day FROM stock UNION SELECT day FROM cash UNION SELECT day FROM expenses ORDER BY 1")]
