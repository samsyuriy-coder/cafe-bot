import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from db import DB
from report import build, format_text
from export import export_xlsx


def make():
    d = DB(":memory:")
    d.upsert_item("Самса", 500, "шт")
    d.upsert_item("Плов", 1800, "порц")
    return d


def test_day_math():
    d = make()
    s, p = [i["id"] for i in d.items()][::-1][0], None
    items = {i["name"]: i["id"] for i in d.items()}
    d.add_prepared("2026-11-01", items["Самса"], 30)
    d.add_prepared("2026-11-01", items["Самса"], 10)   # докинули — суммируется
    d.set_left("2026-11-01", items["Самса"], 8)
    d.add_prepared("2026-11-01", items["Плов"], 20)
    d.set_left("2026-11-01", items["Плов"], 5)
    d.set_cash("2026-11-01", cash=20000, kaspi=40000, drawer=5000)
    d.add_expense("2026-11-01", "Закупка", 10000, "мясо", 1)
    d.add_expense("2026-11-01", "Зарплата", 8000, "", 1)
    r = build("2026-11-01", d.stock_rows("2026-11-01"), d.expenses("2026-11-01"), d.cash_row("2026-11-01"))
    assert r.calc_revenue == 32 * 500 + 15 * 1800 == 43000
    assert r.fact_revenue == 60000 and r.diff == 17000
    assert r.expenses_total == 18000 and r.net == 42000
    assert "Итог за 2026-11-01" in format_text(r)


def test_missing_left_and_undo():
    d = make()
    i = d.items()[0]["id"]
    d.add_prepared("2026-11-01", i, 10)
    r = build("2026-11-01", d.stock_rows("2026-11-01"), [], None)
    assert r.missing_left and r.calc_revenue == 0
    d.add_expense("2026-11-01", "Прочее", 100, "x", 7)
    assert d.undo_last_expense("2026-11-01", 7)["amount"] == 100
    assert d.undo_last_expense("2026-11-01", 7) is None


def test_export():
    d = make()
    d.set_cash("2026-11-01", cash=1, kaspi=2)
    p = os.path.join(tempfile.mkdtemp(), "x.xlsx")
    export_xlsx(d, p)
    assert os.path.getsize(p) > 0
